﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Collections.ObjectModel;
using SomerenModel;

namespace SomerenDAL
{
    public class DrinksDao : BaseDao
    {
        public List<Drink> GetAllDrinks()
        {
            string query = "SELECT Id, Name, Price, Stock, Sold " +
                            "FROM [Drinks] " +
                            "WHERE CONVERT(VARCHAR, Name)<>'Water'" +
                            "AND CONVERT(VARCHAR, Name)<>'Orangeade'" +
                            "AND CONVERT(VARCHAR, Name)<>'Cherrie Juice'" +
                            "AND Stock>1" +
                            "AND Price>1" +
                            "ORDER BY Stock DESC, Price DESC, Sold DESC";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }

        public void UpdateAllDrinks(string NameDrink, int NewStock)
        {
            string query =  $"UPDATE [Drinks]" +
                            $"SET Stock={NewStock}" +
                            $"WHERE CONVERT(VARCHAR, Name)='{NameDrink}'";

            SqlParameter[] sqlParameters = new SqlParameter[0];
            ExecuteEditQuery(query, sqlParameters);
        }

        private List<Drink> ReadTables(DataTable dataTable)
        {
            List<Drink> drinks = new List<Drink>();

            foreach (DataRow dr in dataTable.Rows)
            {
                Drink drink = new Drink()
                {
                    Number = (int)dr["Id"],
                    Name = (string)(dr["Name"].ToString()),
                    Price = (int)dr["Price"],
                    Stock = (int)dr["Stock"],
                    Sold = (int)dr["Sold"],
                };
                drinks.Add(drink);
            }
            return drinks;
        }
    }
}
